﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Serialization;

namespace GeografskiLokaliteti
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        List<Lokalitet> items = new List<Lokalitet>();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
           
            bool x;
            string naz,temp=sifra.Text;
            int sif;
            float sir, duz;
            x = Int32.TryParse(temp,out sif);
            if(x==true)
            {
                temp = sirina.Text;
                temp = temp.Replace(',', '.');
                x = float.TryParse(temp, out sir);
                if(x==true)
                    {
                    temp = duzina.Text;
                    temp = temp.Replace(',', '.');
                    x = float.TryParse(temp, out duz);
                    if (x == true)
                        {
                            naz = naziv.Text;
                            items.Add(new Lokalitet() { id = sif, s = sir, d = duz, n = naz });
                            lv.ItemsSource = null;
                            lv.ItemsSource = items;
                    }
                    else MessageBox.Show("Nije unet realan broj geografske dužine");
                    }
                else MessageBox.Show("Nije unet realan broj geografske širine");
            }
            else MessageBox.Show("Nije unet ceo broj koji označava šifru");

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Filter = "XML file (*.xml)|*.xml";


            if (save.ShowDialog() == true)
             {

                var serializer = new XmlSerializer(typeof(List<Lokalitet>), new XmlRootAttribute("lokalitet"));
                using (var stream = new StringWriter())
                {
                    serializer.Serialize(stream, items);
                    File.AppendAllText(save.FileName, stream.ToString());
                }  
                 sifra.Text = String.Empty;
                 duzina.Text = String.Empty;
                 sirina.Text = String.Empty;
                 naziv.Text = String.Empty;
             }
        }
    }
}
