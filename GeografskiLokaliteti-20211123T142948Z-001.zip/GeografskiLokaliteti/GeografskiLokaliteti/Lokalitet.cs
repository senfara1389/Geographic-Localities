﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Xml.Serialization;

namespace GeografskiLokaliteti
{
    [Serializable()]
    public class Lokalitet
    {
        [XmlElement("sifra")]
        public int id { get; set; }

        [XmlElement("geosirina")]
        public  float s { get; set; }

        [XmlElement("geoduzina")]
        public float d { get; set; }

        [XmlElement("naziv")]
        public string n { get; set; }
}
}
